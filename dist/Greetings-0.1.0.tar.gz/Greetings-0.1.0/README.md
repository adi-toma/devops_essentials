# devops_essentials

<<<<<<< HEAD
*Commit Lorena Berchesan
=======

>>>>>>> origin/python_code
